import 'package:flutter/material.dart';
import 'package:musso_deme_app/pages/Demarrage2.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:musso_deme_app/wingets/CustomNextButton.dart';

class Demarrage extends StatefulWidget {
  const Demarrage({super.key});

  @override
  _DemarrageState createState() => _DemarrageState();
}

class _DemarrageState extends State<Demarrage> {
  late PageController _pageController;
  final FlutterTts flutterTts = FlutterTts();

  bool _isSpeaking = false;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _initTts();
  }

  /// 🔊 Initialisation du Text-To-Speech
  void _initTts() async {
    await flutterTts.setLanguage("fr-ML");     // meilleure langue dispo pour Bamanankan
    await flutterTts.setPitch(1.1);
    await flutterTts.setSpeechRate(0.45);
    await flutterTts.setVolume(1.0);

    flutterTts.setStartHandler(() {
      setState(() => _isSpeaking = true);
    });

    flutterTts.setCompletionHandler(() {
      setState(() => _isSpeaking = false);
      _navigateToNextPage();
    });

    flutterTts.setErrorHandler((msg) {
      setState(() => _isSpeaking = false);
      _navigateToNextPage();
    });

    // 🔥 Message d'accueil en bamanankan
    final String message = """
I ni ce ! Aw bɛ bɛn Musodeme.
Nin ka application bɛ musow ya ka hakɛw ni ka sɔn wuli.
A bɛ aw bolo ka aw denmisɛn fɛ ka fɛn di, ka wariko fɛ ka taa yɔrɔ min.
I ni ce! I bɛ se ka tɔgɔ koman fɛ !
""";

    await flutterTts.speak(message);
  }

  /// 🔁 Navigation automatique vers Demarrage2 après la voix
  void _navigateToNextPage() {
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => Demarrage2(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          var tween = Tween(begin: begin, end: end);
          return SlideTransition(
            position: animation.drive(tween),
            child: child,
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFC983DE),
        ),
        child: Stack(
          children: [
            /// 📌 Logo centré
            Positioned(
              top: MediaQuery.of(context).size.height / 2 - 150,
              left: 0,
              right: 0,
              child: Image.asset(
                'assets/images/logo.png',
                width: 300,
                height: 300,
              ),
            ),

            /// 🔊 Haut-parleur animé si la voix parle
            Positioned(
              top: MediaQuery.of(context).size.height / 2 + 180,
              left: 0,
              right: 0,
              child: Icon(
                Icons.volume_up,
                color: _isSpeaking ? Colors.yellow : Colors.white,
                size: 60,
              ),
            ),

            /// 🔵 Points + "Skip"
            Positioned(
              bottom: 60,
              left: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _buildDot(active: true),
                      const SizedBox(width: 5),
                      _buildDot(),
                      const SizedBox(width: 5),
                      _buildDot(),
                    ],
                  ),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: _navigateToNextPage,
                    child: const Text(
                      'Skip',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  )
                ],
              ),
            ),

            /// 👉 Bouton Next
            Positioned(
              bottom: 60,
              right: 20,
              child: CustomNextButton(
                onPressed: _navigateToNextPage,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Widget pour les petits points
  Widget _buildDot({bool active = false}) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        color: active ? Colors.white : Colors.white.withOpacity(0.5),
        shape: BoxShape.circle,
      ),
    );
  }
}
